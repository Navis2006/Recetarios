import React, { useState, useMemo, FC, useRef, useEffect } from 'react';
import type { Recipe, Ingredient, View } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import { initialRecipes } from './data/initialData';

// --- ICONS ---
const PlusIcon: FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
  </svg>
);

const BackIcon: FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
    </svg>
);

const TrashIcon: FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);

const PencilIcon: FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" />
    </svg>
);

const UserIcon: FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
    </svg>
);

const ChevronDownIcon: FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);


// --- UI COMPONENTS ---

interface UserMenuProps {
    currentUser: string | null;
    users: string[];
    onLogin: (user: string) => void;
    onLogout: () => void;
    onAddUser: () => void;
}

const UserMenu: FC<UserMenuProps> = ({ currentUser, users, onLogin, onLogout, onAddUser }) => {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [menuRef]);

    const handleSelectUser = (user: string) => {
        onLogin(user);
        setIsOpen(false);
    };

    const handleAddUser = () => {
        onAddUser();
        setIsOpen(false);
    };

    const handleLogout = () => {
        onLogout();
        setIsOpen(false);
    }

    return (
        <div className="relative" ref={menuRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="flex items-center space-x-2 text-white px-3 py-2 rounded-md hover:bg-white/10 transition-colors"
            >
                <UserIcon className="h-6 w-6" />
                <span className="font-semibold text-sm hidden md:inline">{currentUser ? currentUser : 'Iniciar Sesión'}</span>
                <ChevronDownIcon className="h-5 w-5" />
            </button>
            {isOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 text-[#333333]">
                    {users.filter(u => u !== currentUser).map(user => (
                        <a
                            key={user}
                            href="#"
                            onClick={(e) => { e.preventDefault(); handleSelectUser(user); }}
                            className="block px-4 py-2 text-sm hover:bg-[#F4F7F6]"
                        >
                            {user}
                        </a>
                    ))}
                    {users.length > 0 && <div className="border-t border-gray-200 my-1"></div>}
                    <a
                        href="#"
                        onClick={(e) => { e.preventDefault(); handleAddUser(); }}
                        className="block px-4 py-2 text-sm hover:bg-[#F4F7F6] text-[#FF6B6B] font-bold"
                    >
                        Añadir usuario
                    </a>
                    {currentUser && (
                        <>
                            <div className="border-t border-gray-200 my-1"></div>
                            <a
                                href="#"
                                onClick={(e) => { e.preventDefault(); handleLogout(); }}
                                className="block px-4 py-2 text-sm hover:bg-[#F4F7F6]"
                            >
                                Cerrar Sesión
                            </a>
                        </>
                    )}
                </div>
            )}
        </div>
    );
};


interface HeaderProps {
    currentUser: string | null;
    users: string[];
    onLogin: (user: string) => void;
    onLogout: () => void;
    onAddUser: () => void;
}

const Header: FC<HeaderProps> = (props) => (
  <header className="bg-[#2C3E50] shadow-md sticky top-0 z-10">
    <div className="max-w-6xl mx-auto py-2 px-4 flex justify-between items-center">
      <div className="w-24"></div> {/* Spacer */}
      <h1 className="text-xl md:text-2xl text-white font-bold text-center tracking-wider">Recetario Colaborativo</h1>
      <div className="w-24 flex justify-end">
        <UserMenu {...props} />
      </div>
    </div>
  </header>
);

interface SearchBarProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
}
const SearchBar: FC<SearchBarProps> = ({ searchTerm, setSearchTerm }) => (
  <div className="my-8">
    <input
      type="text"
      placeholder="Buscar por nombre o ingrediente..."
      value={searchTerm}
      onChange={(e) => setSearchTerm(e.target.value)}
      className="w-full max-w-2xl mx-auto block p-4 text-lg text-[#333333] bg-white border border-[#E0E0E0] rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-[#FF6B6B] focus:border-transparent transition-all"
    />
  </div>
);

interface RecipeCardProps {
  recipe: Recipe;
  onSelect: (id: string) => void;
  onSelectCreator: (name: string) => void;
}
const RecipeCard: FC<RecipeCardProps> = ({ recipe, onSelect, onSelectCreator }) => (
  <div 
    className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300 cursor-pointer flex flex-col"
    onClick={() => onSelect(recipe.id)}
  >
    <img src={recipe.imageUrl} alt={recipe.name} className="w-full h-48 object-cover" />
    <div className="p-5 flex flex-col flex-grow">
      <h3 className="text-xl font-bold text-[#2C3E50] mb-2">{recipe.name}</h3>
      <p className="text-[#555555] text-sm flex-grow">{recipe.description.substring(0, 100)}...</p>
      <p 
        className="text-[#B0B0B0] font-bold uppercase text-xs mt-4 self-start hover:text-[#FF6B6B] transition-colors"
        onClick={(e) => { e.stopPropagation(); onSelectCreator(recipe.creator); }}
      >
        Por: {recipe.creator}
      </p>
    </div>
  </div>
);

interface FloatingActionButtonProps {
  onClick: () => void;
}
const FloatingActionButton: FC<FloatingActionButtonProps> = ({ onClick }) => (
  <button
    onClick={onClick}
    className="fixed bottom-8 right-8 w-16 h-16 rounded-full bg-gradient-to-br from-[#FF6B6B] to-[#FF8E53] text-white flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-110 transform transition-all duration-300 z-20"
    aria-label="Añadir nueva receta"
  >
    <PlusIcon />
  </button>
);


// --- PAGE COMPONENTS ---

interface HomePageProps {
  recipes: Recipe[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  onSelectRecipe: (id: string) => void;
  onAddRecipe: () => void;
  onSelectCreator: (name: string) => void;
  isLoggedIn: boolean;
}
const HomePage: FC<HomePageProps> = ({ recipes, searchTerm, setSearchTerm, onSelectRecipe, onAddRecipe, onSelectCreator, isLoggedIn }) => (
  <>
    <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
      {recipes.length > 0 ? (
        recipes.map(recipe => (
          <RecipeCard key={recipe.id} recipe={recipe} onSelect={onSelectRecipe} onSelectCreator={onSelectCreator} />
        ))
      ) : (
        <p className="text-[#555555] col-span-full text-center">No se encontraron recetas. ¡Intenta con otra búsqueda!</p>
      )}
    </div>
    {isLoggedIn && <FloatingActionButton onClick={onAddRecipe} />}
  </>
);

interface RecipeDetailPageProps {
    recipe: Recipe;
    currentUser: string | null;
    onBack: () => void;
    onEdit: (id: string) => void;
    onDelete: (id: string) => void;
    onSelectCreator: (name: string) => void;
}
const RecipeDetailPage: FC<RecipeDetailPageProps> = ({ recipe, currentUser, onBack, onEdit, onDelete, onSelectCreator }) => (
    <div className="bg-white p-6 md:p-10 rounded-lg shadow-xl max-w-4xl mx-auto animate-fade-in">
        <button onClick={onBack} className="flex items-center text-[#FF6B6B] font-bold mb-6 hover:underline">
            <BackIcon />
            Volver a todas las recetas
        </button>
        <img src={recipe.imageUrl} alt={recipe.name} className="w-full h-96 object-cover rounded-lg mb-6"/>
        <h1 className="text-4xl font-bold text-[#2C3E50] mb-2">{recipe.name}</h1>
        <div className="text-sm text-[#B0B0B0] mb-6 flex space-x-4">
            <span 
              className="font-bold uppercase hover:text-[#FF6B6B] transition-colors cursor-pointer"
              onClick={() => onSelectCreator(recipe.creator)}
            >
              Por: {recipe.creator}
            </span>
            <span>Publicado el: {new Date(recipe.createdAt).toLocaleDateString()}</span>
        </div>

        {currentUser === recipe.creator && (
            <div className="flex space-x-4 mb-8">
                <button onClick={() => onEdit(recipe.id)} className="flex items-center justify-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                    <PencilIcon /> Editar
                </button>
                <button onClick={() => onDelete(recipe.id)} className="flex items-center justify-center px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">
                    <TrashIcon /> Eliminar
                </button>
            </div>
        )}

        <p className="text-[#555555] text-lg mb-8">{recipe.description}</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-1">
                <h2 className="text-2xl font-bold text-[#2C3E50] border-b-2 border-[#FF6B6B] pb-2 mb-4">Ingredientes</h2>
                <ul className="list-disc list-inside space-y-2 text-[#333333]">
                    {recipe.ingredients.map(ing => (
                        <li key={ing.id}>{ing.quantity} {ing.unit} {ing.name}</li>
                    ))}
                </ul>
            </div>
            <div className="md:col-span-2">
                <h2 className="text-2xl font-bold text-[#2C3E50] border-b-2 border-[#FF6B6B] pb-2 mb-4">Preparación</h2>
                <ol className="list-decimal list-inside space-y-4 text-[#333333]">
                    {recipe.steps.map((step, index) => (
                        <li key={index} className="pl-2">{step}</li>
                    ))}
                </ol>
            </div>
        </div>
    </div>
);


interface RecipeFormPageProps {
  initialRecipe?: Recipe;
  onSave: (recipe: Omit<Recipe, 'id' | 'createdAt' | 'creator'> & { id?: string }) => void;
  onCancel: () => void;
}
const RecipeFormPage: FC<RecipeFormPageProps> = ({ initialRecipe, onSave, onCancel }) => {
  const [name, setName] = useState(initialRecipe?.name || '');
  const [description, setDescription] = useState(initialRecipe?.description || '');
  const [imageUrl, setImageUrl] = useState(initialRecipe?.imageUrl || '');
  const [ingredients, setIngredients] = useState<Ingredient[]>(initialRecipe?.ingredients || [{ id: crypto.randomUUID(), quantity: '', unit: '', name: '' }]);
  const [steps, setSteps] = useState<string[]>(initialRecipe?.steps || ['']);

  const handleIngredientChange = <K extends keyof Omit<Ingredient, 'id'>>(index: number, field: K, value: string) => {
    const newIngredients = [...ingredients];
    newIngredients[index][field] = value;
    setIngredients(newIngredients);
  };
  
  const addIngredient = () => setIngredients([...ingredients, { id: crypto.randomUUID(), quantity: '', unit: '', name: '' }]);
  const removeIngredient = (index: number) => setIngredients(ingredients.filter((_, i) => i !== index));

  const handleStepChange = (index: number, value: string) => {
    const newSteps = [...steps];
    newSteps[index] = value;
    setSteps(newSteps);
  };

  const addStep = () => setSteps([...steps, '']);
  const removeStep = (index: number) => setSteps(steps.filter((_, i) => i !== index));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: initialRecipe?.id,
      name,
      description,
      imageUrl,
      ingredients,
      steps,
    });
  };

  const formInputStyle = "w-full p-3 text-[#333333] bg-white border border-[#E0E0E0] rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-[#FF6B6B] focus:border-transparent transition-all";

  return (
    <div className="bg-white p-6 md:p-10 rounded-lg shadow-xl max-w-4xl mx-auto animate-fade-in">
      <h1 className="text-3xl font-bold text-[#2C3E50] mb-8">{initialRecipe ? 'Editar Receta' : 'Crear Nueva Receta'}</h1>
      <form onSubmit={handleSubmit} className="space-y-8">
        <div>
          <label className="block text-lg font-bold text-[#333333] mb-2">Nombre de la Receta</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} className={formInputStyle} required />
        </div>
        <div>
          <label className="block text-lg font-bold text-[#333333] mb-2">Descripción</label>
          <textarea value={description} onChange={e => setDescription(e.target.value)} className={formInputStyle} rows={4} required />
        </div>
        <div>
          <label className="block text-lg font-bold text-[#333333] mb-2">URL de la Imagen</label>
          <input type="text" value={imageUrl} onChange={e => setImageUrl(e.target.value)} className={formInputStyle} placeholder="https://picsum.photos/..." required />
        </div>

        <div>
          <h2 className="text-2xl font-bold text-[#333333] mb-4">Ingredientes</h2>
          {ingredients.map((ing, index) => (
            <div key={ing.id} className="flex items-center space-x-2 mb-3">
              <input type="text" placeholder="Cant." value={ing.quantity} onChange={e => handleIngredientChange(index, 'quantity', e.target.value)} className={`${formInputStyle} w-1/5`} />
              <input type="text" placeholder="Unidad" value={ing.unit} onChange={e => handleIngredientChange(index, 'unit', e.target.value)} className={`${formInputStyle} w-1/5`} />
              <input type="text" placeholder="Nombre del ingrediente" value={ing.name} onChange={e => handleIngredientChange(index, 'name', e.target.value)} className={`${formInputStyle} w-3/5`} required/>
              <button type="button" onClick={() => removeIngredient(index)} className="p-2 text-red-500 hover:text-red-700">&times;</button>
            </div>
          ))}
          <button type="button" onClick={addIngredient} className="mt-2 px-4 py-2 text-sm text-white bg-[#FF6B6B] rounded-lg hover:bg-opacity-90">Añadir Ingrediente</button>
        </div>

        <div>
          <h2 className="text-2xl font-bold text-[#333333] mb-4">Pasos de Preparación</h2>
          {steps.map((step, index) => (
            <div key={index} className="flex items-center space-x-2 mb-3">
              <textarea value={step} onChange={e => handleStepChange(index, e.target.value)} className={formInputStyle} rows={2} required/>
              <button type="button" onClick={() => removeStep(index)} className="p-2 text-red-500 hover:text-red-700">&times;</button>
            </div>
          ))}
          <button type="button" onClick={addStep} className="mt-2 px-4 py-2 text-sm text-white bg-[#FF6B6B] rounded-lg hover:bg-opacity-90">Añadir Paso</button>
        </div>

        <div className="flex justify-end space-x-4 pt-4">
          <button type="button" onClick={onCancel} className="px-6 py-3 bg-gray-200 text-[#555555] font-bold rounded-lg hover:bg-gray-300 transition-colors">Cancelar</button>
          <button type="submit" className="px-6 py-3 bg-gradient-to-br from-[#FF6B6B] to-[#FF8E53] text-white font-bold rounded-lg hover:shadow-lg transition-shadow">Guardar Receta</button>
        </div>
      </form>
    </div>
  );
};


interface UserProfilePageProps {
    creatorName: string;
    recipes: Recipe[];
    onSelectRecipe: (id: string) => void;
    onBack: () => void;
    onSelectCreator: (name: string) => void;
}
const UserProfilePage: FC<UserProfilePageProps> = ({ creatorName, recipes, onSelectRecipe, onBack, onSelectCreator }) => {
    return (
        <div className="animate-fade-in">
            <button onClick={onBack} className="flex items-center text-[#FF6B6B] font-bold mb-6 hover:underline">
                <BackIcon />
                Volver a todas las recetas
            </button>
            <div className="text-center mb-10">
                <h1 className="text-4xl font-bold text-[#2C3E50]">{creatorName}</h1>
                <p className="text-lg text-[#555555] mt-2">{recipes.length} {recipes.length === 1 ? 'receta compartida' : 'recetas compartidas'}</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {recipes.map(recipe => (
                    <RecipeCard key={recipe.id} recipe={recipe} onSelect={onSelectRecipe} onSelectCreator={onSelectCreator} />
                ))}
            </div>
        </div>
    );
};


// --- MAIN APP COMPONENT ---

export default function App() {
  const [recipes, setRecipes] = useLocalStorage<Recipe[]>('recipes', initialRecipes);
  const [users, setUsers] = useLocalStorage<string[]>('users', ['Ana_Cocina', 'Marco_Italiano', 'Chef_React']);
  const [currentUser, setCurrentUser] = useLocalStorage<string | null>('currentUser', 'Chef_React');
  const [view, setView] = useState<View>({ page: 'home' });
  const [searchTerm, setSearchTerm] = useState('');

  const filteredRecipes = useMemo(() => {
    if (!searchTerm) return recipes;
    const lowercasedFilter = searchTerm.toLowerCase();
    return recipes.filter(recipe =>
      recipe.name.toLowerCase().includes(lowercasedFilter) ||
      recipe.ingredients.some(ing => ing.name.toLowerCase().includes(lowercasedFilter))
    );
  }, [recipes, searchTerm]);

  const handleLogin = (user: string) => setCurrentUser(user);
  const handleLogout = () => setCurrentUser(null);
  const handleAddUser = () => {
    const newUser = prompt("Introduce tu nombre de usuario:");
    if (newUser && newUser.trim()) {
        if (!users.includes(newUser)) {
            setUsers([...users, newUser]);
            setCurrentUser(newUser);
        } else {
            alert("Ese nombre de usuario ya existe. Por favor, elige otro.");
        }
    } else if (newUser !== null) {
        alert("El nombre de usuario no puede estar vacío.");
    }
  };

  const handleSaveRecipe = (recipeData: Omit<Recipe, 'createdAt' | 'creator'>) => {
    if (!currentUser) {
        alert("Debes iniciar sesión para guardar una receta.");
        return;
    }
    
    if (recipeData.id) { // Update
      setRecipes(recipes.map(r => r.id === recipeData.id ? { ...r, ...recipeData, creator: currentUser } : r));
      setView({ page: 'detail', recipeId: recipeData.id });
    } else { // Create
      const newRecipe: Recipe = {
        ...recipeData,
        id: crypto.randomUUID(),
        creator: currentUser,
        createdAt: new Date().toISOString()
      };
      setRecipes([newRecipe, ...recipes]);
      setView({ page: 'home' });
    }
  };

  const handleDeleteRecipe = (id: string) => {
    if (window.confirm("¿Estás seguro de que quieres eliminar esta receta?")) {
      setRecipes(recipes.filter(r => r.id !== id));
      setView({ page: 'home' });
    }
  };
  
  const handleAddRecipeClick = () => {
    if (currentUser) {
        setView({ page: 'form' });
    } else {
        alert("Por favor, inicia sesión para añadir una receta.");
    }
  }

  const renderContent = () => {
    switch (view.page) {
      case 'detail':
        const recipe = recipes.find(r => r.id === view.recipeId);
        return recipe ? <RecipeDetailPage 
                            recipe={recipe} 
                            currentUser={currentUser}
                            onBack={() => setView({ page: 'home' })}
                            onEdit={(id) => setView({ page: 'form', recipeId: id })}
                            onDelete={handleDeleteRecipe}
                            onSelectCreator={(name) => setView({ page: 'profile', creatorName: name})}
                         /> : <div>Receta no encontrada</div>;
      case 'form':
        if (!currentUser) {
            return (
                <div className="text-center p-8 bg-white rounded-lg shadow-xl">
                    <h2 className="text-2xl font-bold text-[#2C3E50]">Acceso Denegado</h2>
                    <p className="text-[#555555] mt-2 mb-6">Debes iniciar sesión para crear o editar una receta.</p>
                    <button onClick={() => setView({ page: 'home' })} className="px-6 py-3 bg-gradient-to-br from-[#FF6B6B] to-[#FF8E53] text-white font-bold rounded-lg hover:shadow-lg transition-shadow">
                        Volver al inicio
                    </button>
                </div>
            );
        }
        const recipeToEdit = recipes.find(r => r.id === view.recipeId);
        // Security check: ensure only the creator can edit
        if (recipeToEdit && recipeToEdit.creator !== currentUser) {
             return (
                <div className="text-center p-8 bg-white rounded-lg shadow-xl">
                    <h2 className="text-2xl font-bold text-[#2C3E50]">Acceso Denegado</h2>
                    <p className="text-[#555555] mt-2 mb-6">No tienes permiso para editar esta receta.</p>
                    <button onClick={() => setView({ page: 'home' })} className="px-6 py-3 bg-gradient-to-br from-[#FF6B6B] to-[#FF8E53] text-white font-bold rounded-lg hover:shadow-lg transition-shadow">
                        Volver al inicio
                    </button>
                </div>
            );
        }
        return <RecipeFormPage 
                    initialRecipe={recipeToEdit}
                    onSave={handleSaveRecipe}
                    onCancel={() => view.recipeId ? setView({ page: 'detail', recipeId: view.recipeId }) : setView({ page: 'home' })}
                />;
      case 'profile':
          const userRecipes = recipes.filter(r => r.creator === view.creatorName);
          return <UserProfilePage 
                    creatorName={view.creatorName}
                    recipes={userRecipes}
                    onSelectRecipe={(id) => setView({ page: 'detail', recipeId: id })}
                    onBack={() => setView({ page: 'home' })}
                    onSelectCreator={(name) => setView({ page: 'profile', creatorName: name})}
                  />
      case 'home':
      default:
        return <HomePage 
                  recipes={filteredRecipes} 
                  searchTerm={searchTerm} 
                  setSearchTerm={setSearchTerm} 
                  onSelectRecipe={(id) => setView({ page: 'detail', recipeId: id })}
                  onAddRecipe={handleAddRecipeClick}
                  onSelectCreator={(name) => setView({ page: 'profile', creatorName: name})}
                  isLoggedIn={!!currentUser}
               />;
    }
  };

  return (
    <div className="min-h-screen text-[#333333]">
      <Header 
        currentUser={currentUser}
        users={users}
        onLogin={handleLogin}
        onLogout={handleLogout}
        onAddUser={handleAddUser}
      />
      <main className="max-w-6xl mx-auto p-4 md:p-8">
        {renderContent()}
      </main>
    </div>
  );
}
